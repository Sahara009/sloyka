import {
  crown,
  homeExtras,
  legs,
  marketBases,
  marketPodiums,
  podiums,
  type HomeExtraId,
  type LegId,
  type PodiumId,
} from "./parts";

export type Line = "home" | "market" | "decor";

export type Art =
  | {
      type: "table";
      podium: PodiumId;
      legs: LegId[]; // снизу вверх: [основная, ярус]
      podiumColor: string; // id цвета из палитры
      legColor: string;
      extra?: HomeExtraId;
    }
  | { type: "stand"; levels: number; colors: string[]; crown?: boolean }
  | { type: "decor"; label: string; variant: "sign" | "tent" | "logo" | "crown" };

export type Product = {
  slug: string;
  name: string;
  line: Line;
  kind: "set" | "part" | "base" | "podium" | "decor";
  price: number | null; // null — цена по запросу
  short: string;
  description: string;
  specs: string[];
  art: Art;
  hit?: boolean;
  /** Сборку можно открыть в конструкторе */
  constructorPreset?: { podium: PodiumId; legs: LegId[]; extra?: HomeExtraId };
};

const legPrice = (id: LegId) => legs.find((l) => l.id === id)!.price;
const podiumPrice = (id: PodiumId) => podiums.find((p) => p.id === id)!.price;
const extraPrice = (id: HomeExtraId) => homeExtras.find((e) => e.id === id)!.price;
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

type SetDef = {
  podium: PodiumId;
  legs: LegId[];
  extra?: HomeExtraId;
  podiumColor: string;
  legColor: string;
  hit?: boolean;
  name?: string;
};

// Готовые сборки из сторис «Собирайте свою комбинацию»
const homeSets: SetDef[] = [
  { podium: "bonbon", legs: ["pumpkin"], podiumColor: "butter", legColor: "pumpkin-spice", hit: true },
  { podium: "fleur", legs: ["muff"], podiumColor: "white", legColor: "cherry", hit: true },
  { podium: "cappottina", legs: ["muff"], podiumColor: "brownie", legColor: "cherry" },
  { podium: "bonbon", legs: ["piccola"], podiumColor: "butter", legColor: "white" },
  { podium: "fleur", legs: ["muff", "pumpkin"], podiumColor: "white", legColor: "cherry", hit: true },
  { podium: "cappottina", legs: ["souffle"], podiumColor: "brownie", legColor: "white" },
  { podium: "bonbon", legs: ["grande", "piccola"], podiumColor: "butter", legColor: "white" },
  { podium: "fleur", legs: ["souffle", "pumpkin"], podiumColor: "white", legColor: "ivory" },
  { podium: "cappottina", legs: ["muff", "pumpkin"], podiumColor: "brownie", legColor: "cherry" },
  // Состав уточнить у заказчика: на фото Fleur с вкладышем Nuts на ножке Muff
  { podium: "fleur", legs: ["muff"], extra: "nuts", podiumColor: "latte", legColor: "latte", name: "Fleur Nuts", hit: true },
  // Состав уточнить: на фото Cappottina + Grande + Attico
  { podium: "cappottina", legs: ["grande"], extra: "attico", podiumColor: "brownie", legColor: "white", name: "Cappottina Dei Dolci" },
];

function setName(s: SetDef) {
  if (s.name) return s.name;
  const top = [...s.legs].reverse().map(cap);
  return [cap(s.podium), ...top].join(" + ");
}

const setProducts: Product[] = homeSets.map((s) => {
  const name = setName(s);
  const price =
    podiumPrice(s.podium) + s.legs.reduce((sum, l) => sum + legPrice(l), 0) + (s.extra ? extraPrice(s.extra) : 0);
  const height = s.legs.reduce((h, l) => h + legs.find((x) => x.id === l)!.height, 0);
  return {
    slug: name.toLowerCase().replace(/\s*\+\s*/g, "-").replace(/\s+/g, "-"),
    name,
    line: "home",
    kind: "set",
    price,
    short: `Десертный столик, высота ножки ${height} см`,
    description:
      "Готовая сборка десертного столика Sloyka Home. Детали можно менять и комбинировать между собой: сегодня одна сборка, завтра другая.",
    specs: [
      `Подиум: ${cap(s.podium)}`,
      `Ножка: ${s.legs.map(cap).join(" + ")}`,
      ...(s.extra ? [`Доп: ${homeExtras.find((e) => e.id === s.extra)!.name}`] : []),
      `Высота ножки: ${height} см`,
      "Материал: пластик",
    ],
    art: { type: "table", podium: s.podium, legs: s.legs, podiumColor: s.podiumColor, legColor: s.legColor, extra: s.extra },
    hit: s.hit,
    constructorPreset: { podium: s.podium, legs: s.legs, extra: s.extra },
  };
});

const partProducts: Product[] = [
  ...podiums.map<Product>((p) => ({
    slug: `podium-${p.id}`,
    name: `Подиум ${p.name}`,
    line: "home",
    kind: "part",
    price: p.price,
    short: p.note,
    description: `${p.note}. Подходит ко всем ножкам Sloyka Home.`,
    specs: ["Материал: пластик", "Цвет: любой из палитры"],
    art: { type: "table", podium: p.id, legs: [], podiumColor: "marzipan", legColor: "marzipan" },
  })),
  ...legs.map<Product>((l) => ({
    slug: `leg-${l.id}`,
    name: `Ножка ${l.name}`,
    line: "home",
    kind: "part",
    price: l.price,
    short: l.note,
    description: `Ножка ${l.name}, высота ${l.height} см. Подходит к разным столешницам.${
      l.doubleSided ? " Двустороннее крепление — можно ставить ярусом над другой ножкой." : ""
    }`,
    specs: [`Высота: ${l.height} см`, "Материал: пластик", "Цвет: любой из палитры"],
    art: { type: "table", podium: "bonbon", legs: [l.id], podiumColor: "marzipan", legColor: "latte" },
  })),
];

const marketProducts: Product[] = [
  // Готовые стенды из сторис «Как собрать стенд»
  {
    slug: "stand-florence-marseille",
    name: "Стенд Флоренция",
    line: "market",
    kind: "set",
    price: marketBases[0].price + 2 * 500,
    short: "База Флоренция + Марсель-25 × 2",
    description: "Двухуровневый стенд для маркетов и витрин.",
    specs: ["База: Флоренция", "Подиумы: Марсель-25 × 2"],
    art: { type: "stand", levels: 2, colors: ["latte", "pumpkin-spice"] },
    hit: true,
  },
  {
    slug: "stand-paris-marquise",
    name: "Стенд Париж",
    line: "market",
    kind: "set",
    price: 1000 + 3 * 500,
    short: "База Париж с логотипом + Маркиза-21 × 3",
    description: "Трёхуровневый стенд с вашим логотипом на боковинах.",
    specs: ["База: Париж", "Подиумы: Маркиза-21 × 3", "2 логотипа в комплекте"],
    art: { type: "stand", levels: 3, colors: ["raspberry-yogurt", "butter", "raspberry-yogurt"] },
  },
  {
    slug: "stand-babylon-crown",
    name: "Стенд Вавилон с короной",
    line: "market",
    kind: "set",
    price: 900 + crown.price + 700 + 3 * 600,
    short: "Вавилон + Корона + Каскад-2 + Патио-1, 2, 3",
    description: "Большой стенд с маркизой и подвесной вывеской — для маркетов и кофеен.",
    specs: ["База: Вавилон", "Допы: Корона", "Подиумы: Каскад-2, Патио-3, Патио-2, Патио-1"],
    art: { type: "stand", levels: 3, colors: ["white", "white", "white"], crown: true },
    hit: true,
  },
  ...marketBases.map<Product>((b) => ({
    slug: `base-${b.id}`,
    name: `База ${b.name}`,
    line: "market",
    kind: "base",
    price: b.price,
    short: b.note,
    description: `${b.note}. Подиумы выбираются отдельно.`,
    specs: b.specs,
    art: { type: "stand", levels: b.levels, colors: [] },
  })),
  ...marketPodiums.map<Product>((p) => ({
    slug: `podium-${p.id}`,
    name: `Подиум ${p.name}`,
    line: "market",
    kind: "podium",
    price: p.price,
    short: p.specs[0],
    description: `Подиум ${p.name} для баз Sloyka Market.`,
    specs: [...p.specs, "Комплект: 1 шт"],
    art: { type: "stand", levels: 1, colors: ["marzipan"] },
  })),
];

const decorProducts: Product[] = [
  {
    slug: "crown",
    name: "Корона",
    line: "decor",
    kind: "decor",
    price: crown.price,
    short: "Маркиза с подвесом для вывески",
    description: crown.note,
    specs: ["Ширина 28 см, глубина 7 см, высота 28,5 см", "Комплект: переходник, 2 направляющие, маркиза, табличка, 2 цепочки"],
    art: { type: "decor", label: "Корона", variant: "crown" },
    hit: true,
  },
  {
    slug: "sign",
    name: "Вывеска с логотипом",
    line: "decor",
    kind: "decor",
    price: 1000,
    short: "20 × 20 см — 1000 ₽, 25 × 25 — 1500 ₽, 30 × 30 — 2300 ₽",
    description: "Индивидуальная плоская вывеска с вашим логотипом или меню. Любая форма, до 4 цветов, под любой тип крепления.",
    specs: ["20 × 20 см — 1000 ₽", "25 × 25 см — 1500 ₽", "30 × 30 см — 2300 ₽", "До 4 цветов"],
    art: { type: "decor", label: "ваш лого", variant: "sign" },
  },
  {
    slug: "table-tent",
    name: "Тейблтент",
    line: "decor",
    kind: "decor",
    price: 900,
    short: "15 × 20 см с логотипом",
    description: "Тейблтент любой формы: логотип, QR-код, меню. Другие размеры — по запросу.",
    specs: ["15 × 20 см с лого — 900 ₽", "До 4 цветов", "Прочие размеры — цена по запросу"],
    art: { type: "decor", label: "QR · меню", variant: "tent" },
  },
  {
    slug: "logo-stand",
    name: "Логотип на подставке",
    line: "decor",
    kind: "decor",
    price: null,
    short: "Любые размеры до 30 см",
    description: "Объёмный логотип на подставке, до 4 цветов. Цена по запросу.",
    specs: ["До 30 см", "До 4 цветов", "Цена по запросу"],
    art: { type: "decor", label: "logo", variant: "logo" },
  },
];

export const products: Product[] = [...setProducts, ...partProducts, ...marketProducts, ...decorProducts];

export const lineTitles: Record<Line, string> = {
  home: "Sloyka Home",
  market: "Sloyka Market",
  decor: "Декор и вывески",
};

export function productBySlug(slug: string) {
  return products.find((p) => p.slug === slug);
}

export function similarProducts(p: Product, count = 4) {
  return products.filter((x) => x.line === p.line && x.slug !== p.slug && x.kind === p.kind).slice(0, count);
}

export const hits = products.filter((p) => p.hit);
