/**
 * Доставка: СДЭК (API v2) и Ozon.
 * Пока заглушки — подключаем, когда заказчик заключит договоры и пришлёт ключи (см. .env.example).
 *
 * СДЭК: токен — POST https://api.cdek.ru/v2/oauth/token (grant_type=client_credentials,
 * client_id=CDEK_ACCOUNT, client_secret=CDEK_SECURE), расчёт — /v2/calculator/tarifflist,
 * создание заказа — /v2/orders. Для выбора ПВЗ на карте — официальный виджет СДЭК.
 * TODO: сверить эндпоинты с документацией СДЭК при подключении.
 */

export type DeliveryMethod = "cdek-pvz" | "cdek-courier" | "ozon-pvz";

export function deliveryConfigured(method: DeliveryMethod) {
  if (method.startsWith("cdek")) return Boolean(process.env.CDEK_ACCOUNT && process.env.CDEK_SECURE);
  return Boolean(process.env.OZON_CLIENT_ID && process.env.OZON_API_KEY);
}

export async function getCdekToken(): Promise<string> {
  const params = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: process.env.CDEK_ACCOUNT ?? "",
    client_secret: process.env.CDEK_SECURE ?? "",
  });
  const res = await fetch("https://api.cdek.ru/v2/oauth/token", { method: "POST", body: params });
  if (!res.ok) throw new Error("СДЭК: не удалось получить токен");
  const json = await res.json();
  return json.access_token as string;
}
