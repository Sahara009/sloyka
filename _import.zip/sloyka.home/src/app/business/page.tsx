import type { Metadata } from "next";
import Link from "next/link";
import { ProductArt } from "@/components/art/ProductArt";
import { StandArt } from "@/components/art/StandArt";
import { RequestForm } from "@/components/ui/RequestForm";
import { Shape } from "@/components/ui/Shape";
import { products } from "@/data/products";
import { formatPrice } from "@/lib/format";

export const metadata: Metadata = {
  title: "Для бизнеса",
  description: "Стенды для маркетов, вывески, тейблтенты и логотипы для кофеен и кондитерских.",
};

export default function BusinessPage() {
  const decor = products.filter((p) => p.line === "decor");

  return (
    <>
      <section className="page-hero bg-stripes-sage">
        <div className="container page-hero__grid">
          <div className="page-hero__card">
            <p className="eyebrow">Sloyka Market</p>
            <h1>
              Для кофеен, кондитерских <span className="script">и маркетов</span>
            </h1>
            <p>Соберите стенд под свою витрину, добавьте вывеску с логотипом и тейблтенты с меню и QR-кодом.</p>
            <div className="row-gap">
              <Link href="/constructor?line=market" className="btn">
                Собрать стенд
              </Link>
              <a href="#request" className="btn btn--ghost">
                Индивидуальный заказ
              </a>
            </div>
          </div>
          <Shape shape="arch-scallop" outline="var(--sage-400)" bg="var(--milk)" ratio="4 / 5">
            <StandArt levels={3} colors={["white", "white", "white"]} crown />
          </Shape>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2>
            Декор <span className="script">с вашим</span> логотипом
          </h2>
          <div className="decor-grid">
            {decor.map((p) => (
              <Link key={p.slug} href={`/catalog/${p.slug}`} className="decor-card">
                <ProductArt art={p.art} className="decor-card__art" />
                <div>
                  <h3>{p.name}</h3>
                  <p className="muted small">{p.short}</p>
                  <strong>{p.price === null ? "Цена по запросу" : `от ${formatPrice(p.price)}`}</strong>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="section--tight">
        <div className="container steps-row">
          {[
            ["Заявка", "Расскажите, что нужно: размеры, цвета, логотип"],
            ["Макет", "Согласуем форму и цвета (до 4 цветов на изделие)"],
            ["Изготовление", "Сроки зависят от объёма — назовём заранее"],
            ["Доставка", "СДЭК или Ozon в ваш город"],
          ].map(([t, d], i) => (
            <div key={t} className="steps-row__item">
              <span className="steps-row__n">{i + 1}</span>
              <h3>{t}</h3>
              <p className="muted">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section" id="request">
        <div className="container request">
          <div>
            <h2>
              Индивидуальный <span className="script">заказ</span>
            </h2>
            <p className="muted">Другие формы вывесок, размеры и наполнение тейблтентов — цена по запросу.</p>
          </div>
          <RequestForm topic="Для бизнеса" />
        </div>
      </section>
    </>
  );
}
