import Link from "next/link";
import { TableArt } from "@/components/art/TableArt";
import { StandArt } from "@/components/art/StandArt";
import { ProductCard } from "@/components/catalog/ProductCard";
import { Shape } from "@/components/ui/Shape";
import { Ticker } from "@/components/ui/Ticker";
import { ArrowIcon } from "@/components/ui/Icons";
import { palette } from "@/data/palette";
import { hits } from "@/data/products";

export default function HomePage() {
  return (
    <>
      {/* Первый экран */}
      <section className="hero">
        <div className="container hero__grid">
          <div className="hero__text">
            <p className="eyebrow">Sloyka Home · Sloyka Market</p>
            <h1>
              Столики, которые <span className="script">собираются</span> как конструктор
            </h1>
            <p className="hero__lead">
              Выбираете подиум, ножку и детали — и получаете свою сборку. Сегодня одна, завтра другая: детали меняются
              между собой.
            </p>
            <div className="row-gap">
              <Link href="/constructor" className="btn">
                Собрать свой столик
              </Link>
              <Link href="/catalog" className="btn btn--ghost">
                Каталог
              </Link>
            </div>
          </div>
          <div className="hero__art">
            <Shape shape="arch-scallop" outline="var(--blue-400)" bg="var(--blue-100)" ratio="4 / 5" className="bg-stripes-blue">
              <TableArt podium="fleur" legs={["muff", "pumpkin"]} podiumColor="white" legColor="cherry" />
            </Shape>
            <div className="hero__badge">
              <Shape shape="quatrefoil" outline="var(--caramel)" bg="var(--cream)">
                <TableArt podium="bonbon" legs={["pumpkin"]} podiumColor="butter" legColor="pumpkin-spice" />
              </Shape>
            </div>
          </div>
        </div>
      </section>

      <Ticker />

      {/* Хиты */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <h2>
              <span className="script">Любимые</span> сборки
            </h2>
            <Link href="/catalog" className="more">
              Весь каталог <ArrowIcon />
            </Link>
          </div>
          <div className="grid-products">
            {hits.slice(0, 4).map((p, i) => (
              <ProductCard key={p.slug} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Две линейки */}
      <section className="section--tight">
        <div className="container lines">
          <Link href="/catalog?line=home" className="line-card bg-gingham">
            <div className="line-card__text">
              <p className="eyebrow">Для дома и праздников</p>
              <h3>Sloyka Home</h3>
              <p>Десертные столики: подиумы Bonbon, Fleur, Cappottina и пять видов ножек.</p>
              <span className="more">
                Смотреть <ArrowIcon />
              </span>
            </div>
            <Shape shape="scallop" outline="var(--blue-400)" bg="var(--milk)" className="line-card__art">
              <TableArt podium="cappottina" legs={["muff"]} podiumColor="brownie" legColor="cherry" />
            </Shape>
          </Link>
          <Link href="/catalog?line=market" className="line-card bg-stripes-sage">
            <div className="line-card__text">
              <p className="eyebrow">Для маркетов и витрин</p>
              <h3>Sloyka Market</h3>
              <p>Стенды из базы, подиумов и короны с вашей вывеской.</p>
              <span className="more">
                Смотреть <ArrowIcon />
              </span>
            </div>
            <Shape shape="arch" outline="var(--sage-400)" bg="var(--milk)" className="line-card__art">
              <StandArt levels={3} colors={["white", "white", "white"]} crown />
            </Shape>
          </Link>
        </div>
      </section>

      {/* Как работает конструктор */}
      <section className="how">
        <div className="scallop-top" style={{ ["--scallop-color" as string]: "var(--blue-200)" }} />
        <div className="how__body">
          <div className="container">
            <h2 className="center">
              Один столик — <span className="script">десятки</span> сборок
            </h2>
            <div className="how__steps">
              <div className="how__step">
                <Shape shape="clover" bg="var(--milk)">
                  <TableArt podium="fleur" legs={[]} podiumColor="latte" legColor="latte" />
                </Shape>
                <p>
                  <b>1. Подиум</b>
                  <br />
                  Bonbon, Fleur или Cappottina
                </p>
              </div>
              <span className="how__plus">+</span>
              <div className="how__step">
                <Shape shape="clover" bg="var(--milk)">
                  <TableArt podium="bonbon" legs={["muff"]} podiumColor="marzipan" legColor="cherry" />
                </Shape>
                <p>
                  <b>2. Ножка</b>
                  <br />
                  от 8 до 14 см, можно в два яруса
                </p>
              </div>
              <span className="how__plus">+</span>
              <div className="how__step">
                <Shape shape="clover" bg="var(--milk)">
                  <TableArt podium="fleur" legs={[]} podiumColor="ivory" legColor="ivory" extra="flower" />
                </Shape>
                <p>
                  <b>3. Детали</b>
                  <br />
                  вкладыши и подиум Attico
                </p>
              </div>
            </div>
            <div className="center">
              <Link href="/constructor" className="btn">
                Открыть конструктор
              </Link>
            </div>
          </div>
        </div>
        <div className="scallop-bottom" style={{ ["--scallop-color" as string]: "var(--blue-200)" }} />
      </section>

      {/* Палитра */}
      <section className="section">
        <div className="container palette-block">
          <div>
            <h2>
              25 цветов <span className="script">пластика</span>
            </h2>
            <p className="muted">
              Каждую деталь можно выбрать в любом цвете палитры: молочные, пастельные, яркие, тёплые и глубокие оттенки.
            </p>
          </div>
          <div className="palette-dots">
            {palette.map((g) => (
              <div key={g.id} className="palette-dots__group">
                <span>{g.title}</span>
                <div>
                  {g.colors.map((c) => (
                    <i key={c.id} style={{ background: c.hex }} title={c.name} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* О бренде — рамка как у Puzzle Pantry */}
      <section className="about-teaser">
        <div className="container about-teaser__grid">
          <div>
            <p className="eyebrow">История бренда</p>
            <h2>
              <span className="script">О</span> Sloyka
            </h2>
            <p>
              {/* TODO: короткий текст от заказчика */}
              Мы делаем подставки и столики, которые не надоедают: их можно пересобирать под каждый праздник, витрину и
              настроение.
            </p>
            <Link href="/about" className="btn btn--ghost">
              Узнать больше
            </Link>
          </div>
          <Shape shape="ornate" outline="var(--caramel)" bg="var(--cream)" ratio="1 / 1" className="bg-stripes-caramel">
            <TableArt podium="cappottina" legs={["grande"]} podiumColor="brownie" legColor="white" extra="attico" />
          </Shape>
        </div>
      </section>

      {/* Для бизнеса */}
      <section className="section--tight">
        <div className="container">
          <div className="biz-banner">
            <div>
              <h2>
                Для кофеен <span className="script">и маркетов</span>
              </h2>
              <p>Стенды с вашим логотипом, вывески, тейблтенты и корона-маркиза. Делаем под ваш стиль.</p>
            </div>
            <Link href="/business" className="btn btn--milk">
              Для бизнеса
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
