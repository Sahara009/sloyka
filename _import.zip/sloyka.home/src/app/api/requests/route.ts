import { NextResponse } from "next/server";

/**
 * Заявки с форм «Для бизнеса» и «Контакты».
 * TODO (бэкенд): сохранять в БД и отправлять уведомление заказчику в Telegram-бот.
 */
export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body?.name || !body?.contact || body?.pd !== "on") {
    return NextResponse.json({ error: "Заполните имя, контакт и дайте согласие" }, { status: 400 });
  }
  console.log("[request]", body.topic, body.name, body.contact);
  return NextResponse.json({ ok: true });
}
