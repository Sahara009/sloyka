import { NextResponse } from "next/server";
import { tbankConfigured, tbankInit } from "@/lib/integrations/tbank";
import { site } from "@/lib/format";

type OrderBody = {
  customer: { name: string; phone: string; email: string };
  delivery: { method: string; address: string };
  comment?: string;
  consents: { personalData: boolean; offer: boolean };
  items: { key: string; name: string; price: number; qty: number; details?: string[] }[];
};

/**
 * Создание заказа.
 * Сейчас: проверяем данные и, если подключён Т-Банк, получаем ссылку на оплату.
 * TODO (бэкенд): сохранить заказ в БД, пересчитать цены на сервере по базе товаров,
 * отправить уведомление заказчику в Telegram, создать отправление в СДЭК/Ozon после оплаты.
 */
export async function POST(req: Request) {
  let body: OrderBody;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Некорректный запрос" }, { status: 400 });
  }

  if (!body.consents?.personalData || !body.consents?.offer) {
    return NextResponse.json({ error: "Нужно согласие на обработку данных и принятие оферты" }, { status: 400 });
  }
  if (!body.items?.length) return NextResponse.json({ error: "Корзина пуста" }, { status: 400 });
  if (!body.customer?.name || !body.customer?.phone || !body.customer?.email) {
    return NextResponse.json({ error: "Заполните имя, телефон и email" }, { status: 400 });
  }

  // ВАЖНО: цены с клиента не доверяем — после подключения БД пересчитать здесь.
  const amount = body.items.reduce((s, i) => s + i.price * i.qty, 0);
  const orderId = `SL-${Date.now().toString(36).toUpperCase()}`;

  if (tbankConfigured()) {
    try {
      const { paymentUrl } = await tbankInit({
        orderId,
        amountRub: amount,
        description: `Заказ ${orderId} — Sloyka`,
        email: body.customer.email,
        phone: body.customer.phone,
        items: body.items,
        successUrl: `${site.url}/cart?paid=${orderId}`,
        failUrl: `${site.url}/cart?failed=${orderId}`,
      });
      return NextResponse.json({ orderId, paymentUrl });
    } catch (e) {
      return NextResponse.json({ error: e instanceof Error ? e.message : "Ошибка оплаты" }, { status: 502 });
    }
  }

  // Демо-режим без ключей эквайринга
  console.log("[order]", orderId, amount, body.customer.name, body.delivery);
  return NextResponse.json({ orderId });
}
