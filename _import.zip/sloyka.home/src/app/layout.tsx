import type { Metadata } from "next";
import type { ReactNode } from "react";
import { CartProvider } from "@/components/cart/CartProvider";
import { Analytics } from "@/components/consent/Analytics";
import { CookieBanner } from "@/components/consent/CookieBanner";
import { Footer } from "@/components/layout/Footer";
import { Header } from "@/components/layout/Header";
import { site } from "@/lib/format";
import { body, heading, script } from "./fonts";

import "@/styles/tokens.css";
import "@/styles/base.css";
import "@/styles/patterns.css";
import "@/styles/components.css";
import "@/styles/pages.css";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: "Sloyka — десертные столики и стенды-конструкторы",
    template: "%s · Sloyka",
  },
  description:
    "Десертные столики Sloyka Home и стенды Sloyka Market: собирайте подиум, ножку и детали как конструктор. 25 цветов, доставка СДЭК и Ozon.",
  openGraph: {
    type: "website",
    locale: "ru_RU",
    siteName: "Sloyka",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className={`${heading.variable} ${body.variable} ${script.variable}`}>
      <body>
        <CartProvider>
          <Header />
          <main>{children}</main>
          <Footer />
          <CookieBanner />
          <Analytics />
        </CartProvider>
      </body>
    </html>
  );
}
