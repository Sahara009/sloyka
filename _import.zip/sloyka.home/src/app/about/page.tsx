import type { Metadata } from "next";
import Link from "next/link";
import { TableArt } from "@/components/art/TableArt";
import { StandArt } from "@/components/art/StandArt";
import { Shape } from "@/components/ui/Shape";
import { Ticker } from "@/components/ui/Ticker";

export const metadata: Metadata = { title: "История бренда", description: "Как появилась Sloyka и почему наши столики собираются как конструктор." };

// TODO: тексты истории бренда пришлёт заказчик — ниже заглушки той же длины
export default function AboutPage() {
  return (
    <>
      <section className="container page">
        <div className="about-hero">
          <div>
            <p className="eyebrow">История бренда</p>
            <h1>
              <span className="script">Как появилась</span> Sloyka
            </h1>
            <p className="lead">
              Здесь будет история бренда: с чего всё началось, кто стоит за Sloyka и почему мы решили делать подставки,
              которые собираются как конструктор.
            </p>
          </div>
          <Shape shape="ornate" outline="var(--caramel)" bg="var(--cream)" className="bg-stripes-caramel">
            <TableArt podium="bonbon" legs={["grande", "piccola"]} podiumColor="butter" legColor="white" />
          </Shape>
        </div>
      </section>

      <Ticker items={["сегодня одна сборка", "завтра другая", "детали меняются", "25 цветов"]} tone="blue" />

      <section className="section">
        <div className="container facts">
          <div className="fact">
            <Shape shape="scallop" bg="var(--blue-100)">
              <TableArt podium="fleur" legs={["souffle"]} podiumColor="white" legColor="ivory" />
            </Shape>
            <h3>Sloyka Home</h3>
            <p className="muted">Десертные столики для дома, праздников и фотосессий.</p>
          </div>
          <div className="fact">
            <Shape shape="clover" bg="var(--sage-100)">
              <StandArt levels={2} colors={["latte", "pumpkin-spice"]} />
            </Shape>
            <h3>Sloyka Market</h3>
            <p className="muted">Стенды для маркетов, кофеен и мастеров — с вашим логотипом.</p>
          </div>
          <div className="fact">
            <Shape shape="quatrefoil" bg="var(--blush-100)">
              <TableArt podium="cappottina" legs={["pumpkin"]} podiumColor="powder" legColor="raspberry-yogurt" />
            </Shape>
            <h3>Конструктор</h3>
            <p className="muted">Одна основа — десятки сборок. Меняйте детали под настроение.</p>
          </div>
        </div>
      </section>

      <section className="about-quote bg-gingham">
        <div className="container">
          <blockquote>
            «Место для цитаты основателя бренда — пара тёплых предложений о том, ради чего всё это.»
          </blockquote>
          <Link href="/catalog" className="btn">
            Перейти в каталог
          </Link>
        </div>
      </section>
    </>
  );
}
