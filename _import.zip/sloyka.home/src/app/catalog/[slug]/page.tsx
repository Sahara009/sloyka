import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductArt } from "@/components/art/ProductArt";
import { AddToCart } from "@/components/cart/AddToCart";
import { ProductCard } from "@/components/catalog/ProductCard";
import { Shape } from "@/components/ui/Shape";
import { lineTitles, productBySlug, products, similarProducts } from "@/data/products";
import { formatPrice } from "@/lib/format";

type Params = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return products.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const p = productBySlug(slug);
  if (!p) return {};
  return { title: p.name, description: `${p.short}. ${p.description}` };
}

export default async function ProductPage({ params }: Params) {
  const { slug } = await params;
  const product = productBySlug(slug);
  if (!product) notFound();

  const similar = similarProducts(product);

  return (
    <div className="container page">
      <nav className="crumbs" aria-label="Хлебные крошки">
        <Link href="/catalog">Каталог</Link> / <Link href={`/catalog?line=${product.line}`}>{lineTitles[product.line]}</Link> /{" "}
        {product.name}
      </nav>

      <div className="product">
        <div className="product__media">
          <Shape shape="quatrefoil" outline="var(--blue-400)" bg="var(--blue-100)" stroke={6} className="bg-stripes-blue">
            <ProductArt art={product.art} title={product.name} />
          </Shape>
        </div>

        <div className="product__info">
          <p className="eyebrow">{lineTitles[product.line]}</p>
          <h1 className="product__title">{product.name}</h1>
          <p className="product__price">{formatPrice(product.price)}</p>
          <p>{product.description}</p>

          <AddToCart product={product} />

          {product.constructorPreset && (
            <Link href={`/constructor?preset=${product.slug}`} className="more">
              Изменить сборку в конструкторе →
            </Link>
          )}

          <div className="accordion">
            <details open>
              <summary>Характеристики</summary>
              <div>
                <ul className="specs">
                  {product.specs.map((s) => (
                    <li key={s}>{s}</li>
                  ))}
                </ul>
              </div>
            </details>
            <details>
              <summary>Доставка и оплата</summary>
              <div>
                Отправляем СДЭК и Ozon по всей России. Оплата картой или через СБП.{" "}
                <Link href="/delivery">Подробнее</Link>
              </div>
            </details>
            <details>
              <summary>Уход</summary>
              <div>
                {/* TODO: уточнить у заказчика рекомендации по уходу */}
                Протирайте влажной мягкой тканью. Не используйте абразивные губки и не мойте в посудомоечной машине.
              </div>
            </details>
          </div>
        </div>
      </div>

      {similar.length > 0 && (
        <section className="section">
          <h2 className="center">
            Вам <span className="script">также</span> понравится
          </h2>
          <div className="grid-products">
            {similar.map((p, i) => (
              <ProductCard key={p.slug} product={p} index={i} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
