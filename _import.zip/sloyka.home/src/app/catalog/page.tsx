import type { Metadata } from "next";
import { CatalogView } from "@/components/catalog/CatalogView";

export const metadata: Metadata = {
  title: "Каталог",
  description: "Десертные столики Sloyka Home, стенды Sloyka Market, комплектующие и декор.",
};

export default function CatalogPage() {
  return (
    <div className="container page">
      <div className="page-head">
        <h1>
          <span className="script">Наш</span> каталог
        </h1>
        <p className="muted">Готовые сборки, комплектующие для конструктора и декор для бизнеса.</p>
      </div>
      <CatalogView />
    </div>
  );
}
