import type { Metadata } from "next";
import { CartView } from "@/components/cart/CartView";

export const metadata: Metadata = { title: "Корзина", robots: { index: false } };

export default function CartPage() {
  return (
    <div className="container page">
      <div className="page-head">
        <h1>Корзина</h1>
      </div>
      <CartView />
    </div>
  );
}
