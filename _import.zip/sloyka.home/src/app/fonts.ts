import { Bad_Script, Cormorant_Garamond, Manrope } from "next/font/google";

/**
 * Шрифты сайта. Клиент ещё выбирает пару — менять здесь, в одном месте.
 * Варианты из плана: Playfair Display + Montserrat / Cormorant Garamond + Inter / Lora + Manrope.
 */
export const heading = Cormorant_Garamond({
  subsets: ["latin", "cyrillic"],
  weight: ["500", "600", "700"],
  style: ["normal", "italic"],
  variable: "--font-heading",
  display: "swap",
});

export const body = Manrope({
  subsets: ["latin", "cyrillic"],
  variable: "--font-body",
  display: "swap",
});

/** Рукописный акцент — как «Shop» у Puzzle Pantry */
export const script = Bad_Script({
  subsets: ["latin", "cyrillic"],
  weight: "400",
  variable: "--font-script",
  display: "swap",
});
