"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { CartIcon, CloseIcon, MenuIcon } from "@/components/ui/Icons";
import { Logo } from "@/components/ui/Logo";

export const nav = [
  { href: "/catalog", label: "Каталог" },
  { href: "/constructor", label: "Конструктор" },
  { href: "/business", label: "Для бизнеса" },
  { href: "/about", label: "История бренда" },
  { href: "/contacts", label: "Контакты" },
];

export function Header() {
  const { count } = useCart();
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <header className="header">
      <div className="announce">Доставка СДЭК и Ozon по всей России · оплата картой и СБП</div>
      <div className="header__bar container">
        <nav className="header__nav" aria-label="Основное меню">
          {nav.slice(0, 3).map((n) => (
            <Link key={n.href} href={n.href} className={pathname?.startsWith(n.href) ? "is-active" : ""}>
              {n.label}
            </Link>
          ))}
        </nav>
        <Logo />
        <div className="header__right">
          <nav className="header__nav" aria-label="О бренде">
            {nav.slice(3).map((n) => (
              <Link key={n.href} href={n.href} className={pathname?.startsWith(n.href) ? "is-active" : ""}>
                {n.label}
              </Link>
            ))}
          </nav>
          <Link href="/cart" className="header__cart" aria-label={`Корзина, товаров: ${count}`}>
            <CartIcon />
            {count > 0 && <span className="badge">{count}</span>}
          </Link>
          <button type="button" className="header__burger" onClick={() => setOpen((v) => !v)} aria-label="Меню" aria-expanded={open}>
            {open ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>
      </div>
      {open && (
        <nav className="mobile-nav bg-stripes-blue" aria-label="Мобильное меню">
          {nav.map((n) => (
            <Link key={n.href} href={n.href}>
              {n.label}
            </Link>
          ))}
          <Link href="/delivery">Доставка и оплата</Link>
        </nav>
      )}
    </header>
  );
}
