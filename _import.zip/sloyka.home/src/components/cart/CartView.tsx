"use client";

import Link from "next/link";
import { useState, type FormEvent } from "react";
import { ProductArt } from "@/components/art/ProductArt";
import { formatPrice } from "@/lib/format";
import { useCart } from "./CartProvider";

const deliveryOptions = [
  { id: "cdek-pvz", label: "СДЭК — пункт выдачи", hint: "Стоимость посчитаем по адресу" },
  { id: "cdek-courier", label: "СДЭК — курьер", hint: "До двери" },
  { id: "ozon-pvz", label: "Ozon — пункт выдачи", hint: "Стоимость посчитаем по адресу" },
];

type Status = { type: "idle" } | { type: "sending" } | { type: "done"; orderId: string; paymentUrl?: string } | { type: "error"; message: string };

export function CartView() {
  const { items, total, setQty, remove, clear } = useCart();
  const [delivery, setDelivery] = useState(deliveryOptions[0].id);
  const [status, setStatus] = useState<Status>({ type: "idle" });

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    setStatus({ type: "sending" });
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer: {
            name: form.get("name"),
            phone: form.get("phone"),
            email: form.get("email"),
          },
          delivery: { method: delivery, address: form.get("address") },
          comment: form.get("comment"),
          consents: { personalData: form.get("pd") === "on", offer: form.get("offer") === "on" },
          items: items.map((i) => ({ key: i.key, name: i.name, price: i.price, qty: i.qty, details: i.details })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Не получилось оформить заказ");
      if (data.paymentUrl) {
        window.location.href = data.paymentUrl;
        return;
      }
      clear();
      setStatus({ type: "done", orderId: data.orderId });
    } catch (err) {
      setStatus({ type: "error", message: err instanceof Error ? err.message : "Ошибка" });
    }
  };

  if (status.type === "done") {
    return (
      <div className="empty">
        <h2>Спасибо, заказ №{status.orderId} принят!</h2>
        <p>Мы свяжемся с вами, чтобы подтвердить детали и сроки изготовления.</p>
        <Link className="btn" href="/catalog">
          Вернуться в каталог
        </Link>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="empty">
        <h2>
          Корзина пока <span className="script">пустая</span>
        </h2>
        <p>Соберите свой столик в конструкторе или выберите готовую сборку.</p>
        <div className="row-gap">
          <Link className="btn" href="/constructor">
            В конструктор
          </Link>
          <Link className="btn btn--ghost" href="/catalog">
            В каталог
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="cart">
      <ul className="cart__list">
        {items.map((i) => (
          <li key={i.key} className="cart__item">
            <div className="cart__art">{i.art && <ProductArt art={i.art} />}</div>
            <div>
              <p className="cart__name">{i.name}</p>
              {i.details && (
                <ul className="cart__details">
                  {i.details.map((d) => (
                    <li key={d}>{d}</li>
                  ))}
                </ul>
              )}
              <button type="button" className="link-btn" onClick={() => remove(i.key)}>
                Удалить
              </button>
            </div>
            <div className="cart__right">
              <div className="qty qty--sm">
                <button type="button" onClick={() => setQty(i.key, i.qty - 1)} aria-label="Меньше">
                  −
                </button>
                <span>{i.qty}</span>
                <button type="button" onClick={() => setQty(i.key, i.qty + 1)} aria-label="Больше">
                  +
                </button>
              </div>
              <strong>{formatPrice(i.price * i.qty)}</strong>
            </div>
          </li>
        ))}
      </ul>

      <form className="checkout" onSubmit={onSubmit}>
        <h2>Оформление</h2>
        <label className="field">
          <span>Имя</span>
          <input name="name" required autoComplete="name" />
        </label>
        <label className="field">
          <span>Телефон</span>
          <input name="phone" type="tel" required autoComplete="tel" placeholder="+7" />
        </label>
        <label className="field">
          <span>Email для чека</span>
          <input name="email" type="email" required autoComplete="email" />
        </label>

        <fieldset className="field">
          <span>Доставка</span>
          {deliveryOptions.map((o) => (
            <label key={o.id} className={`radio ${delivery === o.id ? "is-active" : ""}`}>
              <input type="radio" name="delivery" value={o.id} checked={delivery === o.id} onChange={() => setDelivery(o.id)} />
              <span>
                {o.label}
                <small>{o.hint}</small>
              </span>
            </label>
          ))}
        </fieldset>
        {/* TODO: заменить на виджет выбора ПВЗ СДЭК / Ozon */}
        <label className="field">
          <span>{delivery === "cdek-courier" ? "Адрес доставки" : "Город и адрес пункта выдачи"}</span>
          <input name="address" required />
        </label>
        <label className="field">
          <span>Комментарий</span>
          <textarea name="comment" rows={3} />
        </label>

        <div className="checkout__total">
          <span>Товары</span>
          <strong>{formatPrice(total)}</strong>
        </div>
        <p className="muted small">Доставка оплачивается при получении или рассчитывается после подтверждения заказа.</p>

        <label className="check">
          <input type="checkbox" name="pd" required />
          <span>
            Даю <Link href="/legal/consent">согласие на обработку персональных данных</Link>
          </span>
        </label>
        <label className="check">
          <input type="checkbox" name="offer" required />
          <span>
            Принимаю условия <Link href="/legal/offer">публичной оферты</Link>
          </span>
        </label>

        <button className="btn btn--block" disabled={status.type === "sending"}>
          {status.type === "sending" ? "Отправляем…" : `Оплатить ${formatPrice(total)} · карта или СБП`}
        </button>
        {status.type === "error" && <p className="error">{status.message}</p>}
      </form>
    </div>
  );
}
