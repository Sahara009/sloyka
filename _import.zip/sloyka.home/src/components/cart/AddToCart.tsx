"use client";

import { useState } from "react";
import { colorById } from "@/data/palette";
import type { Product } from "@/data/products";
import { useCart } from "./CartProvider";
import { Swatches } from "@/components/ui/Swatches";
import { formatPrice } from "@/lib/format";

/** Блок покупки на странице товара: цвет, количество, кнопка «В корзину» */
export function AddToCart({ product }: { product: Product }) {
  const { add } = useCart();
  const [color, setColor] = useState(product.art.type === "table" ? product.art.podiumColor : "marzipan");
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  if (product.price === null) {
    return (
      <a className="btn" href="/business#request">
        Оставить заявку
      </a>
    );
  }

  const onAdd = () => {
    const colorName = colorById(color).name;
    add(
      {
        key: `${product.slug}:${color}`,
        slug: product.slug,
        name: product.name,
        price: product.price!,
        details: [`Цвет: ${colorName}`],
        art: product.art.type === "table" ? { ...product.art, podiumColor: color } : product.art,
      },
      qty,
    );
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <div className="buy">
      <Swatches value={color} onChange={setColor} label={`Цвет: ${colorById(color).name}`} />
      <div className="buy__row">
        <div className="qty">
          <button type="button" onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Меньше">
            −
          </button>
          <span>{qty}</span>
          <button type="button" onClick={() => setQty((q) => q + 1)} aria-label="Больше">
            +
          </button>
        </div>
        <button type="button" className="btn" onClick={onAdd}>
          {added ? "Добавлено ✓" : `В корзину · ${formatPrice(product.price * qty)}`}
        </button>
      </div>
    </div>
  );
}
