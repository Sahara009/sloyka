"use client";

import { useEffect, useMemo, useState } from "react";
import { lineTitles, products, type Line } from "@/data/products";
import { ProductCard } from "./ProductCard";

const filters: { id: "all" | Line; label: string }[] = [
  { id: "all", label: "Все" },
  { id: "home", label: lineTitles.home },
  { id: "market", label: lineTitles.market },
  { id: "decor", label: lineTitles.decor },
];

const kinds = [
  { id: "all", label: "Всё" },
  { id: "set", label: "Готовые сборки" },
  { id: "part", label: "Комплектующие" },
  { id: "base", label: "Базы" },
  { id: "podium", label: "Подиумы" },
] as const;

export function CatalogView() {
  const [line, setLine] = useState<"all" | Line>("all");
  const [kind, setKind] = useState<(typeof kinds)[number]["id"]>("all");

  // ?line=home из ссылок на главной
  useEffect(() => {
    const p = new URLSearchParams(window.location.search).get("line");
    if (p === "home" || p === "market" || p === "decor") setLine(p);
  }, []);

  const list = useMemo(
    () => products.filter((p) => (line === "all" || p.line === line) && (kind === "all" || p.kind === kind)),
    [line, kind],
  );

  const availableKinds = kinds.filter((k) => k.id === "all" || products.some((p) => (line === "all" || p.line === line) && p.kind === k.id));

  return (
    <div className="catalog">
      <aside className="catalog__side">
        <p className="catalog__label">Линейка</p>
        {filters.map((f) => (
          <button
            key={f.id}
            type="button"
            className={`side-link ${line === f.id ? "is-active" : ""}`}
            onClick={() => {
              setLine(f.id);
              setKind("all");
            }}
          >
            {f.label}
            <sup>{f.id === "all" ? products.length : products.filter((p) => p.line === f.id).length}</sup>
          </button>
        ))}
      </aside>
      <div>
        <div className="chips">
          {availableKinds.map((k) => (
            <button key={k.id} type="button" className={`chip ${kind === k.id ? "is-active" : ""}`} onClick={() => setKind(k.id)}>
              {k.label}
            </button>
          ))}
        </div>
        <div className="grid-products">
          {list.map((p, i) => (
            <ProductCard key={p.slug} product={p} index={i} />
          ))}
        </div>
        {list.length === 0 && <p className="muted">Пока здесь пусто.</p>}
      </div>
    </div>
  );
}
