import Link from "next/link";
import type { Product } from "@/data/products";
import { ProductArt } from "@/components/art/ProductArt";
import { Shape, type ShapeName } from "@/components/ui/Shape";
import { formatPrice } from "@/lib/format";

const shapes: ShapeName[] = ["quatrefoil", "arch-scallop", "clover", "scallop"];
const tones = [
  { bg: "var(--blue-100)", outline: "var(--blue-400)" },
  { bg: "var(--cream)", outline: "var(--caramel)" },
  { bg: "var(--sage-100)", outline: "var(--sage-400)" },
  { bg: "var(--blush-100)", outline: "var(--bordeaux-300)" },
];

/** Карточка товара в фигурной маске — формы и цвета чередуются, как в референсе ilovepink */
export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const tone = tones[index % tones.length];
  return (
    <Link href={`/catalog/${product.slug}`} className="pcard">
      <Shape shape={shapes[index % shapes.length]} outline={tone.outline} bg={tone.bg} stroke={4}>
        <ProductArt art={product.art} className="pcard__art" title={product.name} />
      </Shape>
      {product.hit && <span className="pcard__tag">хит</span>}
      <span className="pcard__name">{product.name}</span>
      <span className="pcard__meta">{product.short}</span>
      <span className="pcard__price">{formatPrice(product.price)}</span>
    </Link>
  );
}
