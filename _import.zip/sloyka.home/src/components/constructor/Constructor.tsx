"use client";

import { useEffect, useMemo, useState, type ReactNode } from "react";
import { colorById } from "@/data/palette";
import {
  crown,
  homeExtras,
  legs,
  marketBases,
  marketPodiums,
  maxPodiums,
  podiums,
  stackableLegs,
  type HomeExtraId,
  type LegId,
  type PodiumId,
} from "@/data/parts";
import { productBySlug } from "@/data/products";
import { TableArt } from "@/components/art/TableArt";
import { StandArt } from "@/components/art/StandArt";
import { useCart } from "@/components/cart/CartProvider";
import { Shape } from "@/components/ui/Shape";
import { Swatches } from "@/components/ui/Swatches";
import { formatPrice } from "@/lib/format";

type Mode = "home" | "market";

export function Constructor() {
  const [mode, setMode] = useState<Mode>("home");

  useEffect(() => {
    const q = new URLSearchParams(window.location.search);
    if (q.get("line") === "market") setMode("market");
  }, []);

  return (
    <div className="builder">
      <div className="tabs" role="tablist">
        <button role="tab" aria-selected={mode === "home"} className={mode === "home" ? "is-active" : ""} onClick={() => setMode("home")}>
          Десертный столик <small>Sloyka Home</small>
        </button>
        <button role="tab" aria-selected={mode === "market"} className={mode === "market" ? "is-active" : ""} onClick={() => setMode("market")}>
          Стенд <small>Sloyka Market</small>
        </button>
      </div>
      {mode === "home" ? <HomeBuilder /> : <MarketBuilder />}
    </div>
  );
}

/* ---------------- общие кусочки ---------------- */

function Step({ n, title, hint, children }: { n: number; title: string; hint?: string; children: ReactNode }) {
  return (
    <section className="step">
      <header className="step__head">
        <span className="step__n">{n}</span>
        <h3>{title}</h3>
        {hint && <p className="step__hint">{hint}</p>}
      </header>
      {children}
    </section>
  );
}

function Option({
  active,
  disabled,
  onClick,
  title,
  sub,
  price,
  art,
}: {
  active: boolean;
  disabled?: boolean;
  onClick: () => void;
  title: string;
  sub?: string;
  price?: number;
  art?: ReactNode;
}) {
  return (
    <button type="button" className={`opt ${active ? "is-active" : ""}`} disabled={disabled} onClick={onClick} aria-pressed={active}>
      {art && <span className="opt__art">{art}</span>}
      <span className="opt__title">{title}</span>
      {sub && <span className="opt__sub">{sub}</span>}
      {price !== undefined && <span className="opt__price">{formatPrice(price)}</span>}
    </button>
  );
}

function Summary({ lines, total, onAdd, note }: { lines: [string, number][]; total: number; onAdd: () => void; note?: string }) {
  const [added, setAdded] = useState(false);
  return (
    <div className="summary">
      <ul>
        {lines.map(([name, price], i) => (
          <li key={i}>
            <span>{name}</span>
            <span>{formatPrice(price)}</span>
          </li>
        ))}
      </ul>
      {note && <p className="summary__note">{note}</p>}
      <div className="summary__total">
        <span>Итого</span>
        <strong>{formatPrice(total)}</strong>
      </div>
      <button
        type="button"
        className="btn btn--block"
        onClick={() => {
          onAdd();
          setAdded(true);
          setTimeout(() => setAdded(false), 1800);
        }}
      >
        {added ? "Сборка в корзине ✓" : "Добавить сборку в корзину"}
      </button>
    </div>
  );
}

/* ---------------- Sloyka Home ---------------- */

function HomeBuilder() {
  const { add } = useCart();
  const [podium, setPodium] = useState<PodiumId>("fleur");
  const [mainLeg, setMainLeg] = useState<LegId>("muff");
  const [topLeg, setTopLeg] = useState<LegId | null>(null);
  const [extra, setExtra] = useState<HomeExtraId | null>(null);
  const [podiumColor, setPodiumColor] = useState("white");
  const [legColor, setLegColor] = useState("cherry");

  // ?preset=fleur-pumpkin-muff — открыть готовую сборку из каталога
  useEffect(() => {
    const slug = new URLSearchParams(window.location.search).get("preset");
    const p = slug ? productBySlug(slug) : undefined;
    if (p?.constructorPreset && p.art.type === "table") {
      setPodium(p.constructorPreset.podium);
      setMainLeg(p.constructorPreset.legs[0]);
      setTopLeg(p.constructorPreset.legs[1] ?? null);
      setExtra(p.constructorPreset.extra ?? null);
      setPodiumColor(p.art.podiumColor);
      setLegColor(p.art.legColor);
    }
  }, []);

  const availableExtras = homeExtras.filter((e) => e.forPodium === podium);

  // Правила совместимости
  useEffect(() => {
    if (!extra) return;
    const e = homeExtras.find((x) => x.id === extra)!;
    if (e.forPodium !== podium || (e.requiresLeg && e.requiresLeg !== mainLeg)) setExtra(null);
  }, [podium, mainLeg, extra]);

  const legStack: LegId[] = topLeg ? [mainLeg, topLeg] : [mainLeg];

  const lines = useMemo(() => {
    const l: [string, number][] = [];
    const p = podiums.find((x) => x.id === podium)!;
    l.push([`Подиум ${p.name} · ${colorById(podiumColor).name}`, p.price]);
    legStack.forEach((id, i) => {
      const leg = legs.find((x) => x.id === id)!;
      l.push([`${i ? "Ярус" : "Ножка"} ${leg.name} · ${colorById(legColor).name}`, leg.price]);
    });
    if (extra) {
      const e = homeExtras.find((x) => x.id === extra)!;
      l.push([e.name, e.price]);
    }
    return l;
  }, [podium, legStack.join(), extra, podiumColor, legColor]); // eslint-disable-line react-hooks/exhaustive-deps

  const total = lines.reduce((s, [, p]) => s + p, 0);
  const height = legStack.reduce((h, id) => h + legs.find((l) => l.id === id)!.height, 0);
  const name = [podiums.find((p) => p.id === podium)!.name, ...[...legStack].reverse().map((id) => legs.find((l) => l.id === id)!.name)].join(" + ");

  return (
    <div className="builder__layout">
      <div className="builder__preview">
        <Shape shape="arch" bg="var(--blue-100)" className="builder__stage bg-stripes-blue">
          <TableArt
            podium={podium}
            legs={legStack}
            podiumColor={podiumColor}
            legColor={legColor}
            extra={extra ?? undefined}
            className="builder__art"
            title={name}
          />
        </Shape>
        <p className="builder__caption">
          <span className="script">{name}</span>
          <br />
          высота ножки {height} см
        </p>
      </div>

      <div className="builder__steps">
        <Step n={1} title="Выберите подиум">
          <div className="opts">
            {podiums.map((p) => (
              <Option
                key={p.id}
                active={podium === p.id}
                onClick={() => setPodium(p.id)}
                title={p.name}
                sub={p.note}
                price={p.price}
                art={<TableArt podium={p.id} legs={[]} podiumColor={podiumColor} legColor={legColor} />}
              />
            ))}
          </div>
        </Step>

        <Step n={2} title="Затем — ножку" hint="Ножки подходят ко всем столешницам">
          <div className="opts opts--5">
            {legs.map((l) => (
              <Option
                key={l.id}
                active={mainLeg === l.id}
                onClick={() => setMainLeg(l.id)}
                title={l.name}
                sub={`${l.height} см`}
                price={l.price}
                art={<TableArt podium="bonbon" legs={[l.id]} podiumColor="marzipan" legColor={legColor} />}
              />
            ))}
          </div>
        </Step>

        <Step n={3} title="Второй ярус" hint="Piccola и Pumpkin с двусторонним креплением ставятся над основной ножкой">
          <div className="opts">
            <Option active={topLeg === null} onClick={() => setTopLeg(null)} title="Без яруса" />
            {legs
              .filter((l) => stackableLegs.includes(l.id))
              .map((l) => (
                <Option key={l.id} active={topLeg === l.id} onClick={() => setTopLeg(l.id)} title={l.name} sub={`+${l.height} см`} price={l.price} />
              ))}
          </div>
        </Step>

        <Step n={4} title="Добавьте детали" hint={podium === "bonbon" ? "Для Bonbon дополнительных деталей нет" : undefined}>
          {availableExtras.length > 0 && (
            <div className="opts">
              <Option active={extra === null} onClick={() => setExtra(null)} title="Без деталей" />
              {availableExtras.map((e) => {
                const blocked = !!e.requiresLeg && e.requiresLeg !== mainLeg;
                return (
                  <Option
                    key={e.id}
                    active={extra === e.id}
                    disabled={blocked}
                    onClick={() => setExtra(e.id)}
                    title={e.name}
                    sub={blocked ? "Только с ножкой Grande" : e.note}
                    price={e.price}
                  />
                );
              })}
            </div>
          )}
        </Step>

        <Step n={5} title="Цвета">
          <div className="builder__colors">
            <Swatches value={podiumColor} onChange={setPodiumColor} label={`Подиум: ${colorById(podiumColor).name}`} />
            <Swatches value={legColor} onChange={setLegColor} label={`Ножка: ${colorById(legColor).name}`} />
          </div>
          <p className="muted small">Цвета могут незначительно отличаться из-за настроек экрана и партии пластика.</p>
        </Step>

        <Summary
          lines={lines}
          total={total}
          onAdd={() =>
            add({
              key: `home:${podium}:${legStack.join("+")}:${extra ?? ""}:${podiumColor}:${legColor}`,
              name: `Сборка ${name}`,
              price: total,
              details: lines.map(([n]) => n),
              art: { type: "table", podium, legs: legStack, podiumColor, legColor, extra: extra ?? undefined },
            })
          }
        />
      </div>
    </div>
  );
}

/* ---------------- Sloyka Market ---------------- */

function MarketBuilder() {
  const { add } = useCart();
  const [baseId, setBaseId] = useState(marketBases[0].id);
  const [picked, setPicked] = useState<string[]>(["marseille-25", "marseille-25"]);
  const [withCrown, setWithCrown] = useState(false);
  const [color, setColor] = useState("raspberry-yogurt");

  const base = marketBases.find((b) => b.id === baseId)!;
  const limit = maxPodiums(base);

  useEffect(() => {
    setPicked((p) => p.slice(0, limit));
  }, [limit]);

  const groups = Array.from(new Set(marketPodiums.map((p) => p.group)));
  const countOf = (id: string) => picked.filter((x) => x === id).length;

  const lines: [string, number][] = [
    [`База ${base.name}`, base.price],
    ...picked.map((id) => {
      const p = marketPodiums.find((x) => x.id === id)!;
      return [`Подиум ${p.name}`, p.price] as [string, number];
    }),
    ...(withCrown ? [[crown.name, crown.price] as [string, number]] : []),
  ];
  const total = lines.reduce((s, [, p]) => s + p, 0);

  return (
    <div className="builder__layout">
      <div className="builder__preview">
        <Shape shape="arch" bg="var(--sage-100)" className="builder__stage bg-gingham">
          <StandArt
            levels={base.levels}
            colors={Array.from({ length: base.levels }, (_, i) => (picked[i] ? color : "marzipan"))}
            crown={withCrown}
            className="builder__art"
          />
        </Shape>
        <p className="builder__caption">
          <span className="script">Стенд {base.name}</span>
          <br />
          подиумов {picked.length} из {limit}
        </p>
      </div>

      <div className="builder__steps">
        <Step n={1} title="Выберите базу">
          <div className="opts">
            {marketBases.map((b) => (
              <Option
                key={b.id}
                active={baseId === b.id}
                onClick={() => setBaseId(b.id)}
                title={b.name}
                sub={`${b.levels} уровня · ${b.note.toLowerCase()}`}
                price={b.price}
                art={<StandArt levels={b.levels} colors={[]} />}
              />
            ))}
          </div>
        </Step>

        <Step n={2} title="Подиумы" hint={`Можно добавить до ${limit} подиумов на эту базу`}>
          {groups.map((g) => (
            <div key={g} className="podium-group">
              <p className="podium-group__title">{g}</p>
              <div className="counter-list">
                {marketPodiums
                  .filter((p) => p.group === g)
                  .map((p) => (
                    <div key={p.id} className="counter">
                      <div>
                        <strong>{p.name}</strong>
                        <span className="muted small">
                          {p.specs[0]} · {formatPrice(p.price)}
                        </span>
                      </div>
                      <div className="qty qty--sm">
                        <button
                          type="button"
                          aria-label={`Убрать ${p.name}`}
                          disabled={countOf(p.id) === 0}
                          onClick={() => {
                            const i = picked.lastIndexOf(p.id);
                            setPicked((prev) => prev.filter((_, k) => k !== i));
                          }}
                        >
                          −
                        </button>
                        <span>{countOf(p.id)}</span>
                        <button
                          type="button"
                          aria-label={`Добавить ${p.name}`}
                          disabled={picked.length >= limit}
                          onClick={() => setPicked((prev) => [...prev, p.id])}
                        >
                          +
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </Step>

        <Step n={3} title="Допы">
          <div className="opts">
            <Option active={!withCrown} onClick={() => setWithCrown(false)} title="Без короны" />
            <Option active={withCrown} onClick={() => setWithCrown(true)} title="Корона" sub="Маркиза и табличка 17 × 7 см под ваш логотип" price={crown.price} />
          </div>
        </Step>

        <Step n={4} title="Цвет подиумов">
          <Swatches value={color} onChange={setColor} label={colorById(color).name} />
        </Step>

        <Summary
          lines={lines}
          total={total}
          note="Вывески, тейблтенты и логотипы — в разделе «Для бизнеса»."
          onAdd={() =>
            add({
              key: `market:${baseId}:${[...picked].sort().join("+")}:${withCrown}:${color}`,
              name: `Стенд ${base.name}`,
              price: total,
              details: [...lines.map(([n]) => n), `Цвет: ${colorById(color).name}`],
              art: { type: "stand", levels: base.levels, colors: picked.slice(0, base.levels).map(() => color), crown: withCrown },
            })
          }
        />
      </div>
    </div>
  );
}
