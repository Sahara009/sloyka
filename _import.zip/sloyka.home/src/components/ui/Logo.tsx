import Link from "next/link";

/**
 * Временный текстовый логотип.
 * TODO: заменить на логотип заказчика (SVG с аватарки Instagram) — положить в /public/logo.svg
 */
export function Logo() {
  return (
    <Link href="/" className="logo" aria-label="Sloyka — на главную">
      <span className="logo__word">Sloyka</span>
      <span className="logo__sub">home · market</span>
    </Link>
  );
}
